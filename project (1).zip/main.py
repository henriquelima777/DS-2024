import machine
import time
from machine import Pin, I2C
import ssd1306

i2c = I2C(0, scl=Pin(22), sda=Pin(21))

largura = 128
altura = 64
tela = ssd1306.SSD1306_I2C(largura, altura, i2c)

led = machine.Pin(25, machine.Pin.OUT)
led2 = machine.Pin(27, machine.Pin.OUT)
botao = machine.Pin(17, machine.Pin.IN, machine.Pin.PULL_UP)
botao2 = machine.Pin(15, machine.Pin.IN, machine.Pin.PULL_UP)

ultimo_estado = 1

led_atual = 0

while True:

    estado = botao.value()
    estado2 = botao2.value()

    if estado != ultimo_estado and estado == 0:
        tela.fill(0)
        tela.text('SOCIEDADE', 0, 0)
        tela.text('ESPORTIVA', 0, 10)
        tela.text('PALMEIRAS', 0, 20)
        tela.show()
        led.on() 
        time.sleep(2)
        led.off()

    if estado2 != ultimo_estado and estado2 == 0:
        tela.fill(0)
        tela.text('MAIOR', 0, 0)
        tela.text('TIME', 0, 10)
        tela.text('DO BRASIL', 0, 20)
        tela.show()
        led2.on() 
        time.sleep(2)
        led2.off()

    ultimo_estado = estado
    time.sleep(0.1)